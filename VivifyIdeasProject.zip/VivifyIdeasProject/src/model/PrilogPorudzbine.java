package model;

public class PrilogPorudzbine {
    private Prilog prilog;
    private int kolicina;

    public Prilog getPrilog() {
        return prilog;
    }

    public void setPrilog(Prilog prilog) {
        this.prilog = prilog;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }
}
