package model;

public enum TipHrane {
    PIZZA,
    PASTA
}
