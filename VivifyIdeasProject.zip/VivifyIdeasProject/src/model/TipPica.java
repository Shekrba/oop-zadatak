package model;

public enum TipPica {
    GAZIRANI_SOK,
    NEGAZIRANI_SOK,
    VODA
}
